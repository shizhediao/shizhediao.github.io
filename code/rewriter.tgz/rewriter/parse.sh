files=$1
#sep=$2
PARSERDIR=/fs/clip-ml/he/tools/stanford-parser-full-2015-01-30
for file in $files; do
  java -Xmx16g -cp "$PARSERDIR/*:" edu.stanford.nlp.parser.lexparser.LexicalizedParser \
   -nthreads 8 \
   -sentences newline \
   -tokenized \
   -escaper edu.stanford.nlp.process.PTBEscapingProcessor \
   -outputFormatOptions "basicDependencies" \
   -outputFormat "words,oneline" edu/stanford/nlp/models/lexparser/englishPCFG.ser.gz $file > $file.parsed
done

